package com.tcs.SampleRestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleRestApiApplication.class, args);
	}

}
