package com.tcs.SampleRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
